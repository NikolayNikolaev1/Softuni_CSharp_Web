﻿using GameStore.Application.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;
using WebServer.Server.HTTP.Contracts;

namespace GameStore.Application.Controllers
{
    public class UserController : Controller
    {
        public IHttpResponse Register()
            => this.FileViewResponse(@"user\register");
    }
}
