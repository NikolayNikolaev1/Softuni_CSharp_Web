﻿namespace GameStore.Application
{
    using Controllers;
    using WebServer.Server.Contracts;
    using WebServer.Server.Routing.Contracts;

    public class MainApplication : IApplication
    {
        public void Start(IAppRouteConfig appRouteConfig)
        {
            appRouteConfig.Get("/register",
                req => new UserController().Register());
        }
    }
}
